from flask import jsonify

def fib(n):
    if n == 0:
        return 0
    if n ==1: 
        return 1
    else:
        return fib(n-1) + fib(n-2)



def entry_handler(request):
    """Responds to any HTTP request.
    Args:
        request (flask.Request): HTTP request object.
    Returns:
        The response text or any set of values that can be turned into a
        Response object using
        `make_response <http://flask.pocoo.org/docs/1.0/api/#flask.Flask.make_response>`.
    """
    # request_json = request.get_json()
    # if request.args and 'message' in request.args:
    #    return request.args.get('message')
    # elif request_json and 'message' in request_json:
    #    return request_json['message']
    # else:
    #    return f'Hello World!'
    

    request_json = request.get_json()
    print(request_json)
    n = request_json['input']
    result = fib(n)
    
    return_value = {'statusCode': 200,
                    'output': result}

    return return_value
    #return jsonify(return_value)
